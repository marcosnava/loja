class AppRoutes {
  static const home = '/';
  static const productDetail = '/product-detail';
  static const cart = '/cart';
  static const orders = '/orders';
}
